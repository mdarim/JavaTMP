package com.javatmp.module.user.repository;

import com.javatmp.fw.data.jpa.repository.ExtendedJpaRepository;
import com.javatmp.module.user.entity.Language;

/**
 *
 * @author JavaTMP
 */
public interface LanguageRepository extends ExtendedJpaRepository<Language, String> {

}
