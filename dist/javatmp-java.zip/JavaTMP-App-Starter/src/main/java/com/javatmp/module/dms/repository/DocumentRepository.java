package com.javatmp.module.dms.repository;

import com.javatmp.fw.data.jpa.repository.ExtendedJpaRepository;
import com.javatmp.module.dms.entity.Document;

public interface DocumentRepository extends ExtendedJpaRepository<Document, Long> {

}
