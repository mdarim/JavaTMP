package com.javatmp.module.event.repository;

import com.javatmp.fw.data.jpa.repository.ExtendedJpaRepository;
import com.javatmp.module.event.entity.Event;

/**
 *
 * @author JavaTMP
 */
public interface EventRepository extends ExtendedJpaRepository<Event, Long> {

}
