
source ./accounting/createAccounting.sql
source ./accounting/createTransactionEntry.sql
source ./accounting/createTransactionEntryTriggers.sql
source ./accounting/testAcctTransEntries.sql